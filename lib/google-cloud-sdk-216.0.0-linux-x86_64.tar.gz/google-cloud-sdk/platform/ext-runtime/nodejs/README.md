
Node.js Externalized Runtime
============================

This is the node.js runtime definition that will soon be used by gcloud for
generating dockerfiles for GAE.
