oauth2client\.contrib\.devshell module
======================================

.. automodule:: oauth2client.contrib.devshell
    :members:
    :undoc-members:
    :show-inheritance:
